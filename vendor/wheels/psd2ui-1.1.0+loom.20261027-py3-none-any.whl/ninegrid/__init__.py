"""Independent lossless nine-slice optimizer; no PSD2UI imports or hooks."""

__version__ = "1.1.0"
